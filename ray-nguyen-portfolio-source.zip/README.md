# Ray Nguyen — Marketing, with momentum

A one-page marketing résumé with self-hosted Inter, a Three.js sculpture, GSAP scroll reveals, three individual career chapters, education and a contact form. No build step or npm installation is required.

## Preview

Run `node scripts/serve.mjs`, then open `http://127.0.0.1:4173`.

`scripts/qa.html` provides narrow-screen preview frames. `node scripts/check-form.mjs` checks form success and failure states with simulated responses, without sending emails.

## Publish on GitHub Pages

Target repository: `https://github.com/ray-nguyen/ray-nguyen.github.io`.

Publish the root of the `master` branch in **Settings → Pages → Deploy from a branch**. Keep `.nojekyll`, `index.html`, `styles.css`, `main.js`, `assets/` and `vendor/` together. Every asset path is relative, so the page works at the account-root URL.

The account-root site URL is `https://ray-nguyen.github.io/`. The repository is named `ray-nguyen.github.io` to match the GitHub account's Pages address.

## Contact activation

The form submits to FormSubmit for `raynguyen.marketer@gmail.com`. On first use, submit a real test message on the published website, then click FormSubmit's activation email in that inbox. Confirm a subsequent message actually arrives before advertising the form as ready. Activation can depend on the deployed origin; localhost verification does not prove production delivery.

The page preserves entered text when submission fails, avoids duplicate submissions, includes a honeypot, and provides a direct email link. A successful API response confirms acceptance by FormSubmit, not final inbox delivery. With JavaScript disabled, the form uses FormSubmit's native flow and CAPTCHA.

FormSubmit processes and stores submission data under its own policy. No API secret is embedded in the site. Provider documentation: https://formsubmit.co/documentation and https://formsubmit.co/help.

## Content and accessibility

Content is based on Ray's supplied October 2026 résumé. Roles and dates: Bami Vietnamese, June 2023–September 2026; Mobo Group, September 2021–June 2023; Barclay Pearce Capital, June 2020–September 2021. Education: University of Wollongong, March 2017–May 2020, with distinction.

All résumé text is semantic HTML. Motion can be paused with the fixed control; the site respects the system's reduced-motion preference. WebGL or animation failure does not hide the résumé. The renderer caps pixel density and pauses while the document is hidden. No analytics or advertising scripts are included. The prior Google site verification is retained.

## Design research

- GSAP ScrollTrigger: https://gsap.com/docs/v3/Plugins/ScrollTrigger/
- GSAP responsive motion: https://gsap.com/docs/v3/GSAP/gsap.matchMedia()/
- Three.js WebGL renderer: https://threejs.org/docs/pages/WebGLRenderer.html
- 2026 scroll-driven 3D portfolio case study: https://tympanus.net/codrops/2026/04/28/more-than-a-portfolio-building-a-scroll-driven-3d-world-with-something-to-say/
- 2026 scroll rotation exploration: https://tympanus.net/codrops/2026/06/18/exploring-3d-image-rotations-on-scroll/

Implementation is original; no reference website assets were copied. Libraries are vendored at Three.js 0.186.0 and GSAP 3.15.0. Inter is distributed under the SIL Open Font License. Attribution and license information are in `vendor/` and `assets/`.
