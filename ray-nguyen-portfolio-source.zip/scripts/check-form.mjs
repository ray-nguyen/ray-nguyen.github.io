import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const source=await readFile(new URL('../main.js',import.meta.url),'utf8');
function harness(fetchImpl) {
  let handler, reset=false, requests=0;
  const generic={textContent:'',style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},removeAttribute(){},addEventListener(){}};
  const label={textContent:'Send message'};
  const button={disabled:false,querySelector:()=>label};
  const status={...generic};
  const form={...generic,elements:{_honey:{value:''}},reportValidity:()=>true,reset(){reset=true;},querySelector:()=>button,addEventListener(event,fn){if(event==='submit')handler=fn;}};
  const elements={'#contact-form':form,'#form-status':status};
  const context={document:{querySelector:s=>elements[s]??generic,querySelectorAll:()=>[],documentElement:{scrollHeight:1000,style:{}},readyState:'loading'},matchMedia:()=>({matches:false,addEventListener(){}}),localStorage:{getItem:()=>null},IntersectionObserver:class{observe(){}},innerHeight:800,scrollY:0,addEventListener(){},requestAnimationFrame(){},setTimeout,clearTimeout,AbortController,FormData:class{},fetch:async(...args)=>{requests++;return fetchImpl(...args);},console};
  vm.runInNewContext(source,context);
  return {submit:()=>handler({preventDefault(){}}),form,button,status,get reset(){return reset},get requests(){return requests}};
}
let t=harness(async()=>({ok:true,json:async()=>({success:'true'})}));await t.submit();assert(t.reset);assert.equal(t.button.disabled,false);assert.match(t.status.textContent,/submitted/);
t=harness(async()=>({ok:true,json:async()=>({success:'false'})}));await t.submit();assert(!t.reset);assert.equal(t.button.disabled,false);assert.match(t.status.textContent,/could not be confirmed/);
t=harness(async()=>{throw Error('offline')});await t.submit();assert(!t.reset);assert.equal(t.button.disabled,false);
t=harness(async()=>({ok:false,json:async()=>({success:true})}));await t.submit();assert(!t.reset);
t=harness(async()=>{throw Error('should not send')});t.form.elements._honey.value='spam';await t.submit();assert.equal(t.requests,0);
let resolve;t=harness(()=>new Promise(r=>{resolve=r}));const pending=t.submit();await t.submit();assert.equal(t.requests,1);resolve({ok:true,json:async()=>({success:true})});await pending;
console.log('PASS: successful submission, API rejection, network failure, HTTP error, honeypot, duplicate prevention. No emails were sent.');
