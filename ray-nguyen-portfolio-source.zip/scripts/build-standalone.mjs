import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
const root=new URL('../',import.meta.url),read=file=>readFile(new URL(file,root),'utf8');
let html=await read('index.html');
const font=(await readFile(new URL('assets/inter-latin-variable.woff2',root))).toString('base64');
const css=(await read('styles.css')).replace("url('./assets/inter-latin-variable.woff2')",`url('data:font/woff2;base64,${font}')`);
html=html.replace(/  <link rel="preload"[^\n]+\n/,'');
html=html.replace('./assets/favicon.svg','data:image/svg+xml,'+encodeURIComponent(await read('assets/favicon.svg')));
for(const file of ['ray-portrait.jpg','workspace.jpg','microphone.jpg','community.jpg','packing-poster.jpg','kitchen-poster.jpg']){
 const data=(await readFile(new URL('assets/'+file,root))).toString('base64');
 html=html.replaceAll('./assets/'+file,'data:image/jpeg;base64,'+data);
}
html=html.replace('<link rel="stylesheet" href="./styles.css">',()=>`<style>${css}</style>`);
const main=await read('main.js');
html=html.replace('<script type="module" src="./main.js"></script>',()=>`<script type="module">${main}</script>`);
const license=await read('assets/INTER-LICENSE.txt');html=html.replace('</html>',()=>`<!-- Inter font license\n${license.replaceAll('--','—')}\n-->\n</html>`);
await mkdir(new URL('publish/',root),{recursive:true});
for(const name of ['packing','kitchen']){html=html.replace('./assets/'+name+'.mp4','./ray-'+name+'.mp4');await copyFile(new URL('assets/'+name+'.mp4',root),new URL('publish/ray-'+name+'.mp4',root));}
await writeFile(new URL('publish/index.html',root),html);
for(const file of ['Ray-Nguyen-Resume.pdf','README.md'])await copyFile(new URL(file,root),new URL('publish/'+file,root));
console.log(`Built cinematic website: ${Math.round(Buffer.byteLength(html)/1024)} KB plus two local video loops.`);
