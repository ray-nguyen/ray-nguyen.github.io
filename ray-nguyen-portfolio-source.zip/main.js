const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
$('#year').textContent=new Date().getFullYear();
const preference=matchMedia('(prefers-reduced-motion: reduce)');
let manualPause=false;try{manualPause=localStorage.getItem('ray-cinema-paused')==='true';}catch{}
let paused=preference.matches||manualPause,frame=0;
const scenes=$$('.scene'),links=$$('.year-nav a'),videos=$$('video');
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const visibleVideos=new Set(),userPaused=new Set();
function videoButton(video){return video.closest('.scene').querySelector('.video-toggle');}
function playVideo(video){
 if(paused||document.hidden||userPaused.has(video)||!visibleVideos.has(video))return;
 if(!video.src){video.src=video.dataset.src;video.load();}
 video.muted=true;
 video.play().then(()=>videoButton(video).textContent='Pause footage').catch(()=>videoButton(video).textContent='Play footage');
}
const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
 const scene=entry.target;scene.classList.toggle('in-view',entry.isIntersecting);
 const video=scene.querySelector('video');if(!video)return;
 if(entry.isIntersecting){visibleVideos.add(video);playVideo(video);}else{visibleVideos.delete(video);video.pause();}
}),{threshold:0,rootMargin:'-110px 0px -10px 0px'});
scenes.forEach(scene=>observer.observe(scene));
videos.forEach(video=>{
 video.addEventListener('playing',()=>video.classList.add('ready'));
 videoButton(video).addEventListener('click',()=>{
  if(!video.paused){video.pause();userPaused.add(video);videoButton(video).textContent='Play footage';}
  else{userPaused.delete(video);if(paused){paused=false;manualPause=false;try{localStorage.setItem('ray-cinema-paused','false');}catch{}applyMotion();}playVideo(video);}
 });
});
function update(){
 frame=0;const height=innerHeight,header=$('.site-header').offsetHeight,mobile=innerWidth<=700;let active=-1;
 scenes.forEach((scene,index)=>{
  const rect=scene.getBoundingClientRect();
  if(rect.top<height*.55&&rect.bottom>height*.45)active=index;
  if(rect.bottom<0||rect.top>height)return;
  const p=clamp((height-rect.top)/(rect.height+height));
  const entrance=clamp((height-rect.top)/(height*.7));
  const held=clamp((header-rect.top)/Math.max(1,rect.height-height+header));
  scene.querySelector('.scene-progress i').style.transform=`scaleX(${held})`;
  const media=scene.querySelector('.scene-media'),copy=scene.querySelector('.scene-copy'),result=scene.querySelector('.scene-result');
  media.style.transform=paused?'none':`translate3d(0,${(p-.5)*(mobile?100:180)}px,0) scale(${1.23-p*.23})`;
  copy.style.transform=paused?'none':`translate3d(${(1-entrance)*(mobile?-25:-90)}px,${(1-entrance)*80-held*30}px,0)`;
  copy.style.opacity=paused?'1':String(.25+.75*entrance);
  result.style.transform=paused?'none':`translate3d(${(1-entrance)*70}px,${(1-entrance)*100-held*65}px,0)`;
  result.style.opacity=paused?'1':String(.3+.7*entrance);
  scene.querySelectorAll('.scene-icon>*').forEach(path=>path.style.strokeDashoffset=paused?'0':String((1-clamp(entrance*1.3))*350));
 });
 links.forEach((a,i)=>i===active?a.setAttribute('aria-current','step'):a.removeAttribute('aria-current'));
 const hero=$('.hero').getBoundingClientRect();
 if(hero.bottom>0){const p=clamp(-hero.top/hero.height);$('.hero-portrait').style.transform=paused?'none':`translate3d(0,${p*90}px,0) rotate(${-p*5}deg)`;$('.filmstrip').style.transform=paused?'none':`translate3d(${p*-100}px,0,0)`;}
}
function queue(){if(!frame)frame=requestAnimationFrame(update);}
function applyMotion(){
 document.documentElement.classList.toggle('motion-paused',paused);
 $('#motion-toggle').textContent=paused?'Resume motion':'Pause motion';$('#motion-toggle').setAttribute('aria-pressed',String(paused));
 if(paused){$$('.scene-media,.scene-copy,.scene-result,.hero-portrait,.filmstrip').forEach(el=>{el.style.transform='none';el.style.opacity='1';});videos.forEach(v=>{v.pause();videoButton(v).textContent='Play footage';});}
 else visibleVideos.forEach(playVideo);
 queue();
}
$('#motion-toggle').addEventListener('click',()=>{paused=!paused;manualPause=paused;try{localStorage.setItem('ray-cinema-paused',String(paused));}catch{}applyMotion();});
preference.addEventListener('change',()=>{paused=preference.matches||manualPause;applyMotion();});
document.addEventListener('visibilitychange',()=>document.hidden?videos.forEach(v=>v.pause()):visibleVideos.forEach(playVideo));
addEventListener('scroll',queue,{passive:true});addEventListener('resize',queue);addEventListener('load',queue);applyMotion();
const form = $('#contact-form');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const status = $('#form-status');
  if (form.elements._honey.value) {status.textContent='Please leave the extra field empty.';return;}
  const button = form.querySelector('button');
  if (button.disabled) return;
  button.disabled = true;
  button.querySelector('span').textContent = 'Sending…';
  status.classList.remove('error');
  status.textContent = 'Sending your message…';
  form.setAttribute('aria-busy','true');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(),20000);
  try {
    const response = await fetch('https://formsubmit.co/ajax/raynguyen.marketer@gmail.com', {
      method:'POST',body:new FormData(form),headers:{Accept:'application/json'},signal:controller.signal
    });
    const result = await response.json();
    if (!response.ok || ![true,'true'].includes(result.success)) throw new Error('Submission was not accepted');
    status.textContent = 'Your message has been submitted. Thanks for getting in touch.';
    form.reset();
  } catch {
    status.classList.add('error');
    status.textContent = 'Your message could not be confirmed. Please try again or email raynguyen.marketer@gmail.com directly. Your message is still here.';
  } finally {
    clearTimeout(timeout);
    button.disabled = false;
    button.querySelector('span').textContent = 'Send message';
    form.removeAttribute('aria-busy');
  }
});

