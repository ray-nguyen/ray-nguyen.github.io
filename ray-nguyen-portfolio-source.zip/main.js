const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
$('#year').textContent=new Date().getFullYear();
const preference=matchMedia('(prefers-reduced-motion: reduce)');
let paused=preference.matches;
try {paused=paused||localStorage.getItem('ray-story-paused')==='true';}catch{}
const chapters=$$('.chapter'), links=$$('.timeline a');
const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
let frame=0;
function update(){
 frame=0;
 const height=innerHeight,mobile=innerWidth<=700;
 const story=$('#story').getBoundingClientRect();
 $('.timeline-line i').style.transform=`scaleX(${clamp((136-story.top)/(story.height-height))})`;
 let active=-1;
 chapters.forEach((chapter,index)=>{
  const rect=chapter.getBoundingClientRect();
  if(rect.top<height*.55 && rect.bottom>height*.4) active=index;
  if(rect.bottom<0||rect.top>height)return;
  const progress=clamp((height-rect.top)/(rect.height+height));
  chapter.querySelectorAll('.parallax').forEach(el=>{
   const depth=Number(el.dataset.depth);
   el.style.transform=paused?'none':`translate3d(0,${(progress-.5)*depth*(mobile?.45:1)}px,0)`;
  });
 });
 links.forEach((a,i)=>i===active?a.setAttribute('aria-current','step'):a.removeAttribute('aria-current'));
 const intro=$('.intro').getBoundingClientRect();
 if(intro.bottom>0) $('.portrait img').style.transform=paused?'none':`translate3d(0,${-clamp(-intro.top/intro.height)*55}px,0)`;
}
function queue(){if(!frame)frame=requestAnimationFrame(update);}
function applyMotion(){
 document.documentElement.classList.toggle('motion-paused',paused);
 $('#motion-toggle').textContent=paused?'Enable parallax':'Pause parallax';
 $('#motion-toggle').setAttribute('aria-pressed',String(paused));
 if(paused){$$('.parallax,.portrait img').forEach(el=>el.style.transform='none');}
 queue();
}
$('#motion-toggle').addEventListener('click',()=>{paused=!paused;try{localStorage.setItem('ray-story-paused',String(paused));}catch{}applyMotion();});
preference.addEventListener('change',()=>{paused=preference.matches;applyMotion();});
addEventListener('scroll',queue,{passive:true});addEventListener('resize',queue);addEventListener('load',queue);
$('.write-note').addEventListener('toggle',queue);
applyMotion();
const form = $('#contact-form');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const status = $('#form-status');
  if (form.elements._honey.value) {status.textContent='Please leave the extra field empty.';return;}
  const button = form.querySelector('button');
  if (button.disabled) return;
  button.disabled = true;
  button.querySelector('span').textContent = 'Sending…';
  status.classList.remove('error');
  status.textContent = 'Sending your message…';
  form.setAttribute('aria-busy','true');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(),20000);
  try {
    const response = await fetch('https://formsubmit.co/ajax/raynguyen.marketer@gmail.com', {
      method:'POST',body:new FormData(form),headers:{Accept:'application/json'},signal:controller.signal
    });
    const result = await response.json();
    if (!response.ok || ![true,'true'].includes(result.success)) throw new Error('Submission was not accepted');
    status.textContent = 'Your message has been submitted. Thanks for getting in touch.';
    form.reset();
  } catch {
    status.classList.add('error');
    status.textContent = 'Your message could not be confirmed. Please try again or email raynguyen.marketer@gmail.com directly. Your message is still here.';
  } finally {
    clearTimeout(timeout);
    button.disabled = false;
    button.querySelector('span').textContent = 'Send message';
    form.removeAttribute('aria-busy');
  }
});

