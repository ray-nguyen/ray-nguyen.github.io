const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const preference = matchMedia('(prefers-reduced-motion: reduce)');
let manualPause = false;
try { manualPause = localStorage.getItem('ray-motion-paused') === 'true'; } catch {}
let paused = preference.matches || manualPause;
let sceneController, motionContext, selectedMode = 0;
const counterStates = new Set();
$('#year').textContent = new Date().getFullYear();

function applyMotion() {
  document.body.classList.toggle('motion-paused', paused);
  document.documentElement.style.scrollBehavior = paused ? 'auto' : '';
  $('#motion-toggle').setAttribute('aria-pressed', String(paused));
  $('#motion-toggle').setAttribute('aria-label', paused ? 'Resume animations' : 'Pause animations');
  $('.motion-text').textContent = paused ? 'Resume motion' : 'Pause motion';
  $('.motion-icon').textContent = paused ? '▶' : 'Ⅱ';
  motionContext?.revert();
  sceneController?.setPaused(paused);
  if (paused) {
    window.gsap?.killTweensOf('.reveal,.career-body,.skill-content,#mode-copy');
    window.gsap?.set('.reveal,.career-body,.skill-content,#mode-copy', {clearProps:'all'});
    counterStates.forEach(state => { window.gsap?.killTweensOf(state); state.finish(); });
    return;
  }
  if (!window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);
  motionContext = gsap.context(() => {
    if (scrollY < 100) {
      gsap.from('.hero h1 .line > span', {yPercent:120, rotation:3, duration:1.15, stagger:.13, ease:'power4.out', clearProps:'all'});
      gsap.from('.hero-kicker,.hero-description,.hero-actions', {y:24, opacity:0, duration:.8, stagger:.12, delay:.3, clearProps:'all'});
      gsap.from('.hero-lab', {opacity:0, y:40, rotation:3, duration:1.2, delay:.35, clearProps:'all'});
    }
    if (matchMedia('(min-width: 761px)').matches) {
      gsap.to('.hero-copy', {y:-35, ease:'none', scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:true}});
      gsap.to('.chapter-wheel > span:first-child', {rotation:270,ease:'none',scrollTrigger:{trigger:'.work',start:'top bottom',end:'bottom top',scrub:true}});
    }
  });
  ScrollTrigger.refresh();
}
$('#motion-toggle').addEventListener('click', () => {
  paused = !paused; manualPause = paused;
  try { localStorage.setItem('ray-motion-paused',String(paused)); } catch {}
  applyMotion();
});
preference.addEventListener('change', () => { paused = preference.matches || manualPause; applyMotion(); });

const revealObserver = new IntersectionObserver(entries => entries.forEach(entry => {
  if (!entry.isIntersecting) return;
  if (!paused && window.gsap) gsap.from(entry.target,{y:35,opacity:0,duration:.9,ease:'power3.out',clearProps:'all'});
  revealObserver.unobserve(entry.target);
}),{threshold:.12});
$$('.reveal').forEach(el => revealObserver.observe(el));
const countObserver = new IntersectionObserver(entries => entries.forEach(entry => {
  if (!entry.isIntersecting) return;
  const el=entry.target, end=Number(el.dataset.count);
  const draw = value => { el.textContent=(el.dataset.prefix || '')+Math.round(value)+(el.dataset.suffix || ''); };
  if (!paused && window.gsap) {
    const state={value:0,finish:()=>draw(end)}; counterStates.add(state);
    gsap.to(state,{value:end,duration:1.6,ease:'power2.out',onUpdate:()=>draw(state.value),onComplete:()=>counterStates.delete(state)});
  }
  countObserver.unobserve(el);
}),{threshold:.7});
$$('[data-count]').forEach(el=>countObserver.observe(el));
let progressFrame;
const progress = () => { progressFrame=0; const distance=document.documentElement.scrollHeight-innerHeight; $('.scroll-progress').style.transform=`scaleX(${distance>0?scrollY/distance:0})`; };
addEventListener('scroll',()=>{if(!progressFrame) progressFrame=requestAnimationFrame(progress);},{passive:true});
addEventListener('resize',progress); progress();
const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
  if(entry.isIntersecting) $$('.header nav a').forEach(a=>a.hash===`#${entry.target.id}`?a.setAttribute('aria-current','location'):a.removeAttribute('aria-current'));
}),{rootMargin:'-20% 0px -60% 0px'});
$$('main > section').forEach(el=>sectionObserver.observe(el));

const modes=[['01 / BRAND THINKING','Build a brand people recognise. Create experiences they remember.'],['02 / DIGITAL FLUENCY','Connect the right message with the right audience. Test, learn and improve.'],['03 / CONNECTED SYSTEMS','Bring the moving parts together. Make the experience work from end to end.']];
$$('[data-mode]').forEach(button=>button.addEventListener('click',()=>{
  selectedMode=Number(button.dataset.mode);
  $$('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  $('.mode-label').textContent=modes[selectedMode][0]; $('#mode-copy').textContent=modes[selectedMode][1];
  $('.lab-coordinate').textContent=`RN / 00${selectedMode+1}`;
  if(!paused && window.gsap) gsap.fromTo('#mode-copy',{opacity:0,y:8},{opacity:1,y:0,duration:.4,overwrite:true});
  sceneController?.setMode(selectedMode);
}));

const skills=[
 ['BRAND & MULTI-SITE MARKETING','Make every touchpoint count.','Connect brand strategy, local area marketing and creative production across multiple locations. Keep every campaign and customer touchpoint working together.',['Brand strategy','Adobe Creative Suite','OOH & print','PR & events'],'career-experience','Bami Vietnamese'],
 ['PAID MEDIA & DIGITAL','Reach the right people.','Turn audience and keyword research into targeted campaigns. Refine creative, geo-targeting and CPA through testing, with conversion tracking that connects the results.',['Meta Ads','Google Ads','Semrush','Pixel & Conversions API'],'career-experience','Bami Vietnamese'],
 ['CRM & AUTOMATION','Keep the connection going.','Bring customer data, email campaigns and automated workflows together to make communications timely, consistent and useful.',['HubSpot','Dynamics 365','Pipedrive','Mailchimp'],'career-mobo','Mobo Group'],
 ['WEBSITES & ECOMMERCE','Turn a visit into possibility.','Build and manage websites and online stores, connecting content, SEO and the customer journey with the tools behind the business.',['WordPress','Wix','Shopify','WooCommerce','Yoast SEO'],'career-mobile-mart','Mobile Mart'],
 ['SYSTEMS & EXPERIENCE','Make the moving parts work.','Connect ordering, loyalty, inventory and customer experiences. Translate business needs into practical platform migrations, integrations and interfaces.',['Odoo','Gecko','Abacus','Lightspeed','Doshii','UI/UX'],'career-experience','Bami Vietnamese'],
 ['DATA & INSIGHTS','Find the story in the numbers.','Use research, reporting and visualisation to understand performance, communicate findings and support better decisions.',['Power BI','Excel','SQL'],null,null]
];
$$('[data-skill]').forEach(button=>button.addEventListener('click',()=>{
  const index=Number(button.dataset.skill), skill=skills[index];
  $$('[data-skill]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  $('#skill-index').textContent=`0${index+1} / ${skill[0]}`;
  $('#skill-title').textContent=skill[1]; $('#skill-description').textContent=skill[2];
  $('#skill-tools').replaceChildren(...skill[3].map(text=>{const span=document.createElement('span');span.textContent=text;return span;}));
  const link=$('#skill-evidence');
  link.href=skill[4]?`#${skill[4]}`:'./Ray-Nguyen-Resume.pdf';
  link.textContent=skill[4]?`See the work at ${skill[5]} ↗`:'Explore my full skillset in the CV ↗';
  if(skill[4]) {link.removeAttribute('target');link.removeAttribute('rel');} else {link.target='_blank';link.rel='noopener noreferrer';}
  if(!paused && window.gsap) gsap.fromTo('.skill-content',{opacity:.25,y:12},{opacity:1,y:0,duration:.45,overwrite:true});
}));
$$('.career').forEach(detail=>detail.addEventListener('toggle',()=>{
  if(detail.open && !paused && window.gsap) gsap.fromTo(detail.querySelector('.career-body'),{opacity:0,y:12},{opacity:1,y:0,duration:.5,clearProps:'all',overwrite:true});
  window.ScrollTrigger?.refresh(); progress();
}));
function openCareer(hash=location.hash) {const target=document.getElementById(hash.slice(1));if(target?.matches('.career')) target.open=true;}
addEventListener('hashchange',()=>openCareer()); openCareer();
$('#skill-evidence').addEventListener('click',event=>openCareer(event.currentTarget.hash));
let printStates=[];
addEventListener('beforeprint',()=>{printStates=$$('.career').map(d=>d.open);$$('.career').forEach(d=>d.open=true);});
addEventListener('afterprint',()=>$$('.career').forEach((d,i)=>d.open=printStates[i]));
$('.copy-email').addEventListener('click',async()=>{
  try {await navigator.clipboard.writeText('raynguyen.marketer@gmail.com');$('#copy-status').textContent='Email address copied.';}
  catch {$('#copy-status').textContent='raynguyen.marketer@gmail.com';}
});

async function createScene() {
  const THREE=await import('./vendor/three.module.min.js');
  const host=$('#scene');
  const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.5)); renderer.setClearColor(0,0);
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.7;
  host.append(renderer.domElement);host.classList.add('webgl-ready');
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(38,1,.1,100);camera.position.z=8.6;
  const envCanvas=document.createElement('canvas');envCanvas.width=512;envCanvas.height=256;
  const ctx=envCanvas.getContext('2d'),gradient=ctx.createLinearGradient(0,0,0,256);
  ['#e0edc6','#535e47','#f5ffe5','#222820','#7f9b64'].forEach((color,i)=>gradient.addColorStop(i/4,color));
  ctx.fillStyle=gradient;ctx.fillRect(0,0,512,256);ctx.fillStyle='#ffffff';ctx.fillRect(30,25,90,150);ctx.fillRect(330,40,35,90);
  const env=new THREE.CanvasTexture(envCanvas);env.mapping=THREE.EquirectangularReflectionMapping;
  const pmrem=new THREE.PMREMGenerator(renderer);scene.environment=pmrem.fromEquirectangular(env).texture;env.dispose();pmrem.dispose();
  scene.add(new THREE.AmbientLight(0xecffd5,1.3));
  const key=new THREE.DirectionalLight(0xe6ffc0,4);key.position.set(-3,4,5);scene.add(key);
  const rim=new THREE.DirectionalLight(0xbde0ff,3);rim.position.set(4,-2,3);scene.add(rim);
  const root=new THREE.Group();scene.add(root);
  const groups=[new THREE.Group(),new THREE.Group(),new THREE.Group()];groups.forEach(g=>root.add(g));
  const material=new THREE.MeshPhysicalMaterial({color:0xc6dc95,metalness:.87,roughness:.26,clearcoat:.8,envMapIntensity:1.25});
  const knot=new THREE.Mesh(new THREE.TorusKnotGeometry(1.18,.26,180,28,2,3),material);knot.rotation.set(.4,.2,.3);groups[0].add(knot);
  for(let i=0;i<7;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(1.25,.095,16,100),material);ring.rotation.x=Math.PI/2;ring.position.y=(i-3)*.3;groups[1].add(ring);}groups[1].rotation.set(.35,.2,-.3);
  const ico=new THREE.IcosahedronGeometry(1.6,0);groups[2].add(new THREE.LineSegments(new THREE.EdgesGeometry(ico),new THREE.LineBasicMaterial({color:0xc9ed86,transparent:true,opacity:.65})));
  const vertices=ico.attributes.position,seen=new Set(),sphere=new THREE.SphereGeometry(.15,20,12);
  for(let i=0;i<vertices.count;i++){const x=vertices.getX(i),y=vertices.getY(i),z=vertices.getZ(i),id=[x,y,z].map(v=>v.toFixed(3)).join();if(seen.has(id))continue;seen.add(id);const point=new THREE.Mesh(sphere,material);point.position.set(x,y,z);groups[2].add(point);}ico.dispose();
  const orbit=new THREE.Mesh(new THREE.TorusGeometry(2.12,.008,6,140),new THREE.MeshBasicMaterial({color:0xafcf77,transparent:true,opacity:.35}));orbit.rotation.set(.85,.25,.2);root.add(orbit);
  const dot=new THREE.Mesh(new THREE.SphereGeometry(.06,12,8),new THREE.MeshBasicMaterial({color:0xd1f266}));dot.position.x=2.12;orbit.add(dot);
  let isPaused=paused,visible=true,frame=0,last=0,time=0,dragging=false,pointerX=0,pointerY=0;
  const rotation={x:.15,y:.2};
  const wake=()=>{if(!frame&&visible&&!document.hidden)frame=requestAnimationFrame(render);};
  function render(now){frame=0;if(!visible||document.hidden)return;const dt=Math.min((now-last)/1000,.05);last=now;if(!isPaused&&!dragging)time+=dt;root.rotation.set(rotation.x+(isPaused?0:Math.sin(time*.2)*.1),rotation.y+time*.16,0);orbit.rotation.z=time*.05;renderer.render(scene,camera);if(!isPaused)wake();}
  const resize=()=>{const box=host.getBoundingClientRect();if(!box.width||!box.height)return;camera.aspect=box.width/box.height;camera.updateProjectionMatrix();renderer.setSize(box.width,box.height);wake();};
  new ResizeObserver(resize).observe(host);
  function setMode(mode){groups.forEach((group,i)=>{group.visible=i===mode;window.gsap?.killTweensOf(group.scale);group.scale.setScalar(1);});host.dataset.mode=mode;if(!isPaused&&window.gsap)gsap.from(groups[mode].scale,{x:.6,y:.6,z:.6,duration:.75,ease:'back.out(1.5)',onUpdate:wake});wake();}
  host.addEventListener('pointerdown',event=>{if(event.button!==0)return;dragging=true;pointerX=event.clientX;pointerY=event.clientY;host.setPointerCapture(event.pointerId);host.classList.add('dragging');});
  host.addEventListener('pointermove',event=>{if(!dragging)return;rotation.y+=(event.clientX-pointerX)*.012;rotation.x=Math.max(-1.3,Math.min(1.3,rotation.x+(event.clientY-pointerY)*.008));pointerX=event.clientX;pointerY=event.clientY;host.dataset.rotation=rotation.y.toFixed(2);wake();});
  const release=()=>{dragging=false;host.classList.remove('dragging');};['pointerup','pointercancel','lostpointercapture'].forEach(name=>host.addEventListener(name,release));
  host.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();if(event.key==='ArrowLeft')rotation.y-=.15;if(event.key==='ArrowRight')rotation.y+=.15;if(event.key==='ArrowUp')rotation.x-=.15;if(event.key==='ArrowDown')rotation.x+=.15;host.dataset.rotation=rotation.y.toFixed(2);wake();});
  $('.reset-scene').addEventListener('click',()=>{rotation.x=.15;rotation.y=.2;time=0;host.dataset.rotation='.20';wake();});
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)wake();else{cancelAnimationFrame(frame);frame=0;}},{rootMargin:'100px'}).observe(host);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else wake();});
  renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();host.classList.remove('webgl-ready');visible=false;});
  renderer.domElement.addEventListener('webglcontextrestored',()=>{visible=true;host.classList.add('webgl-ready');wake();});
  setMode(selectedMode);resize();
  return {setMode,setPaused(value){isPaused=value;if(value)groups.forEach(g=>{window.gsap?.killTweensOf(g.scale);g.scale.setScalar(1);});wake();}};
}
applyMotion();
createScene().then(controller=>{sceneController=controller;controller.setMode(selectedMode);controller.setPaused(paused);}).catch(error=>{
  console.info('Static sculpture fallback:',error.message);$('#scene').classList.remove('webgl-ready');$('#scene').removeAttribute('tabindex');$('#scene').setAttribute('aria-label','Sculptural illustration of connected ideas');$('.reset-scene').hidden=true;$('.drag-hint').textContent='EXPLORE THE APPROACH BELOW';
});
const form = $('#contact-form');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const status = $('#form-status');
  if (form.elements._honey.value) {status.textContent='Please leave the extra field empty.';return;}
  const button = form.querySelector('button');
  if (button.disabled) return;
  button.disabled = true;
  button.querySelector('span').textContent = 'Sending…';
  status.classList.remove('error');
  status.textContent = 'Sending your message…';
  form.setAttribute('aria-busy','true');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(),20000);
  try {
    const response = await fetch('https://formsubmit.co/ajax/raynguyen.marketer@gmail.com', {
      method:'POST',body:new FormData(form),headers:{Accept:'application/json'},signal:controller.signal
    });
    const result = await response.json();
    if (!response.ok || ![true,'true'].includes(result.success)) throw new Error('Submission was not accepted');
    status.textContent = 'Your message has been submitted. Thanks for getting in touch.';
    form.reset();
  } catch {
    status.classList.add('error');
    status.textContent = 'Your message could not be confirmed. Please try again or email raynguyen.marketer@gmail.com directly. Your message is still here.';
  } finally {
    clearTimeout(timeout);
    button.disabled = false;
    button.querySelector('span').textContent = 'Send message';
    form.removeAttribute('aria-busy');
  }
});


