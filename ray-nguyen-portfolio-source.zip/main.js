const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const motionQuery = matchMedia('(prefers-reduced-motion: reduce)');
let manualPause = false;
try { manualPause = localStorage.getItem('ray-motion-paused') === 'true'; } catch {}
let paused = motionQuery.matches || manualPause;
let motionContext;
let sceneController;
$('#year').textContent = new Date().getFullYear();

// The complete résumé stays readable if animation libraries or WebGL are unavailable.
function initialiseReveals() {
  motionContext?.revert();
  document.body.classList.toggle('motion-paused', paused);
  document.documentElement.style.scrollBehavior = paused ? 'auto' : '';
  $('#motion-toggle').setAttribute('aria-pressed', String(paused));
  $('#motion-toggle').setAttribute('aria-label', paused ? 'Enable animations' : 'Pause animations');
  $('.motion-icon').textContent = paused ? '▷' : 'Ⅱ';
  $('.motion-text').textContent = paused ? 'Enable motion' : 'Pause motion';
  sceneController?.setPaused(paused);
  if (!window.gsap || !window.ScrollTrigger || paused) return;
  gsap.registerPlugin(ScrollTrigger);
  motionContext = gsap.context(() => {
    if (window.scrollY < 150) {
      gsap.from('.hero h1 .line > span', {yPercent:110, rotate:4, duration:1.35, stagger:.13, ease:'power4.out', clearProps:'transform'});
      gsap.from('.intro-label, .hero-description, .hero-actions', {y:24, opacity:0, duration:1, stagger:.13, delay:.45, clearProps:'all'});
      gsap.from('.hero-top, .hero-bottom, .header', {opacity:0, duration:1.1, delay:.15, clearProps:'opacity'});
    }
    $$('.reveal').forEach((el) => {
      if (el.getBoundingClientRect().top < innerHeight * .93) return;
      const heading = /H[123]/.test(el.tagName);
      gsap.from(el, {y:heading ? 58 : 28, opacity:0, rotateX:heading ? 12 : 0, transformPerspective:1000,
        duration:heading ? 1.1 : .8, ease:'power3.out', clearProps:'all',
        scrollTrigger:{trigger:el,start:'top 92%',once:true}});
    });
    if (innerWidth > 760) {
      gsap.to('.hero-content', {y:-80, ease:'none', scrollTrigger:{trigger:'.hero', start:'top top',end:'bottom top',scrub:1}});
      $$('.chapter-watermark').forEach((el) => gsap.fromTo(el,{y:80},{y:-85,ease:'none',scrollTrigger:{trigger:el.closest('section'),start:'top bottom',end:'bottom top',scrub:1.2}}));
      gsap.fromTo('.education-seal',{rotation:-25},{rotation:8,ease:'none',scrollTrigger:{trigger:'#education',start:'top bottom',end:'bottom top',scrub:1.5}});
      gsap.from('.expertise',{y:45,stagger:.12,duration:.9,ease:'power3.out',scrollTrigger:{trigger:'.expertise-grid',start:'top 90%',once:true}});
    }
    ScrollTrigger.refresh();
  });
}

$('#motion-toggle').addEventListener('click', () => {
  paused = !paused;
  manualPause = paused;
  try { localStorage.setItem('ray-motion-paused',String(paused)); } catch {}
  initialiseReveals();
});
motionQuery.addEventListener('change', () => {paused = motionQuery.matches || manualPause;initialiseReveals();});

const chapters = $$('.chapter');
const chapterObserver = new IntersectionObserver((entries) => {
  for (const entry of entries) if (entry.isIntersecting) {
    const index = chapters.indexOf(entry.target);
    $('#chapter-number').textContent = String(index + 1).padStart(2,'0');
    $('#chapter-name').textContent = entry.target.dataset.chapter;
  }
}, {rootMargin:'-35% 0px -45% 0px'});
chapters.forEach(el => chapterObserver.observe(el));
let scrollQueued = false;
function updateProgress() {
  const max = document.documentElement.scrollHeight - innerHeight;
  $('.scroll-progress').style.transform = `scaleX(${max > 0 ? scrollY / max : 0})`;
  scrollQueued = false;
}
addEventListener('scroll', () => {if (!scrollQueued) {scrollQueued = true;requestAnimationFrame(updateProgress);}}, {passive:true});
addEventListener('resize',updateProgress,{passive:true});
updateProgress();

// A real mail endpoint, with native HTML fallback if JavaScript is disabled.
const form = $('#contact-form');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const status = $('#form-status');
  if (form.elements._honey.value) {status.textContent='Please leave the extra field empty.';return;}
  const button = form.querySelector('button');
  if (button.disabled) return;
  button.disabled = true;
  button.querySelector('span').textContent = 'Sending…';
  status.classList.remove('error');
  status.textContent = 'Sending your message…';
  form.setAttribute('aria-busy','true');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(),20000);
  try {
    const response = await fetch('https://formsubmit.co/ajax/raynguyen.marketer@gmail.com', {
      method:'POST',body:new FormData(form),headers:{Accept:'application/json'},signal:controller.signal
    });
    const result = await response.json();
    if (!response.ok || ![true,'true'].includes(result.success)) throw new Error('Submission was not accepted');
    status.textContent = 'Your message has been submitted. Thanks for getting in touch.';
    form.reset();
  } catch {
    status.classList.add('error');
    status.textContent = 'Your message could not be confirmed. Please try again or email raynguyen.marketer@gmail.com directly. Your message is still here.';
  } finally {
    clearTimeout(timeout);
    button.disabled = false;
    button.querySelector('span').textContent = 'Send message';
    form.removeAttribute('aria-busy');
  }
});

async function createScene() {
  const THREE = await import('./vendor/three.module.min.js');
  const container = $('#scene');
  const renderer = new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,innerWidth < 760 ? 1.4 : 1.65));
  renderer.setSize(innerWidth,innerHeight);
  renderer.setClearColor(0x141513,0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.5;
  container.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38,innerWidth/innerHeight,.1,100);
  camera.position.z = 9;

  // Small procedural studio environment: no external texture or model requests.
  const studio = document.createElement('canvas');studio.width=1024;studio.height=512;
  const ctx=studio.getContext('2d');
  const gradient=ctx.createLinearGradient(0,0,0,512);
  gradient.addColorStop(0,'#3b4143');gradient.addColorStop(.32,'#e7dfcf');gradient.addColorStop(.48,'#27231d');gradient.addColorStop(.72,'#99978e');gradient.addColorStop(1,'#111513');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,1024,512);
  ctx.fillStyle='#fff5e6';ctx.fillRect(170,15,70,280);ctx.fillRect(720,100,150,190);
  ctx.fillStyle='#161a1a';ctx.fillRect(440,0,210,512);
  const environment = new THREE.CanvasTexture(studio);environment.mapping=THREE.EquirectangularReflectionMapping;
  const pmrem=new THREE.PMREMGenerator(renderer);const envTarget=pmrem.fromEquirectangular(environment);
  scene.environment=envTarget.texture;environment.dispose();pmrem.dispose();
  scene.add(new THREE.AmbientLight(0xffe5d0,.75));
  const key=new THREE.DirectionalLight(0xffdbc0,4);key.position.set(-3,5,6);scene.add(key);
  const fill=new THREE.DirectionalLight(0xb8d4ea,3);fill.position.set(4,-2,3);scene.add(fill);
  const rim=new THREE.DirectionalLight(0xff9e5a,3);rim.position.set(2,4,-4);scene.add(rim);
  const root=new THREE.Group();scene.add(root);
  const materials=[];
  const metal=(color,roughness=.25)=>{const m=new THREE.MeshPhysicalMaterial({color,metalness:.94,roughness,clearcoat:.75,clearcoatRoughness:.2,envMapIntensity:1.25,transparent:true});materials.push(m);return m;};
  const copper=metal(0xc08b67,.27),sage=metal(0xadc3b7,.23),silver=metal(0xb7c3d2,.24);
  const knotGroup=new THREE.Group();
  const knot=new THREE.Mesh(new THREE.TorusKnotGeometry(1.12,.31,240,40,2,3),copper);
  knot.rotation.set(.3,-.3,.4);knotGroup.add(knot);root.add(knotGroup);
  const orbitMaterial=new THREE.MeshBasicMaterial({color:0xba8d6b,transparent:true,opacity:.3});
  const orbit=new THREE.Mesh(new THREE.TorusGeometry(2.07,.006,6,180),orbitMaterial);orbit.rotation.set(.7,.25,.3);knotGroup.add(orbit);
  const bead=new THREE.Mesh(new THREE.SphereGeometry(.065,16,12),copper);bead.position.set(2.07,0,0);orbit.add(bead);
  const ringGroup=new THREE.Group();
  for(let i=0;i<7;i++) {const ring=new THREE.Mesh(new THREE.TorusGeometry(1.35,.10,20,150),sage);ring.position.y=(i-3)*.24;ring.rotation.x=Math.PI/2;ring.rotation.y=(i-3)*.11;ringGroup.add(ring);}
  ringGroup.rotation.set(.5,.2,-.35);root.add(ringGroup);
  const sphereGroup=new THREE.Group();
  for(let i=0;i<19;i++) {const y=(i-9)*.16;const radius=Math.sqrt(Math.max(.08,1.55**2-y*y));const ring=new THREE.Mesh(new THREE.TorusGeometry(radius,.044,10,120),silver);ring.rotation.x=Math.PI/2;ring.position.y=y;sphereGroup.add(ring);}
  sphereGroup.rotation.set(.5,.2,-.4);root.add(sphereGroup);
  const particlesGeometry=new THREE.BufferGeometry();
  const points=[];for(let i=0;i<65;i++) {const a=i*2.399963;const r=2.4+(i%7)*.21;points.push(Math.cos(a)*r,Math.sin(a)*r,(i%5-2)*.24);}
  particlesGeometry.setAttribute('position',new THREE.Float32BufferAttribute(points,3));
  const dust=new THREE.Points(particlesGeometry,new THREE.PointsMaterial({color:0xb89979,size:.014,transparent:true,opacity:.45}));root.add(dust);
  let anchors=[], width=innerWidth,height=innerHeight,frame=0,last=0,time=0,isPaused=paused;
  const pointer={x:0,y:0},smoothPointer={x:0,y:0};
  let blend=[1,0,0], position={x:0,y:0}, previousId='home';
  const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
  function measure() {
    width=innerWidth;height=innerHeight;
    camera.aspect=width/height;camera.updateProjectionMatrix();
    renderer.setSize(width,height);renderer.setPixelRatio(Math.min(devicePixelRatio,width<760?1.4:1.65));
    anchors=['home','experience','mobo','capital','mobile-mart'].map((id,i)=>{
      const section=document.getElementById(id);const rect=section.getBoundingClientRect();const art=section.querySelector('.experience-art');const artRect=art?.getBoundingClientRect();
      return {id,type:i===2?1:i===3?2:0,top:rect.top+scrollY,bottom:rect.bottom+scrollY,
        x:i===0?(width<760?width*.53:width*.79):artRect.left+artRect.width/2,
        y:i===0?(width<760?section.querySelector('.hero-bottom').getBoundingClientRect().top+scrollY-170:height*.51):artRect.top+scrollY+(width<760?180:270),
        size:width<760?(i===0?.57:.60):(width<1100?.82:1.04)};
    });
  }
  const observer=new ResizeObserver(measure);observer.observe(document.querySelector('main'));measure();
  const onScroll=()=>{if(!frame)frame=requestAnimationFrame(render);};
  addEventListener('scroll',onScroll,{passive:true});addEventListener('resize',measure,{passive:true});
  addEventListener('pointermove',e=>{if(e.pointerType==='mouse'&&!isPaused){pointer.x=e.clientX/width-.5;pointer.y=e.clientY/height-.5;}},{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else{last=0;onScroll();}});
  renderer.domElement.addEventListener('webglcontextlost',(event)=>{event.preventDefault();cancelAnimationFrame(frame);frame=0;container.classList.add('webgl-unavailable');});
  renderer.domElement.addEventListener('webglcontextrestored',()=>{container.classList.remove('webgl-unavailable');onScroll();});
  function render(now) {
    frame=0;if(document.hidden)return;
    const dt=Math.min((now-(last||now))/1000,.05);last=now;
    if(!isPaused) time+=dt;
    const center=scrollY+height*.5;
    const active=anchors.find(a=>center>=a.top&&center<a.bottom);
    root.visible=Boolean(active);
    if(active) {
      const viewH=2*Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*camera.position.z;
      const targetX=(active.x-width/2)/height*viewH;
      const targetY=-(active.y-scrollY-height/2)/height*viewH;
      if(isPaused||active.id!==previousId){position.x=targetX;position.y=targetY;}
      position.x+=(targetX-position.x)*.1;position.y+=(targetY-position.y)*.14;previousId=active.id;
      root.position.set(position.x,position.y,0);
      const scale=active.size*Math.min(1,height/800);root.scale.setScalar(scale);
      for(let i=0;i<3;i++)blend[i]+=(Number(active.type===i)-blend[i])*(isPaused?1:.075);
      [knotGroup,ringGroup,sphereGroup].forEach((group,i)=>{group.visible=blend[i]>.01;group.scale.setScalar(.7+blend[i]*.3);});
      copper.opacity=blend[0];sage.opacity=blend[1];silver.opacity=blend[2];orbitMaterial.opacity=blend[0]*.32;
      smoothPointer.x+=(pointer.x-smoothPointer.x)*.04;smoothPointer.y+=(pointer.y-smoothPointer.y)*.04;
      const progress=isPaused?0:(scrollY-active.top)/Math.max(1,active.bottom-active.top);
      root.rotation.set(isPaused?.12:smoothPointer.y*.2+Math.sin(time*.15)*.09,isPaused?-.1:smoothPointer.x*.3+progress*.55,0);
      knot.rotation.y=isPaused?.2:time*.11+progress*1.15;
      knot.rotation.z=isPaused?.4:.4+Math.sin(time*.16)*.1;
      ringGroup.rotation.y=isPaused?.3:time*.14+progress*.8;
      sphereGroup.rotation.z=isPaused?-.3:time*.08+progress*.6;
      orbit.rotation.z=isPaused?.3:time*.04;dust.rotation.z=isPaused?0:-time*.018;
    }
    renderer.render(scene,camera);
    if(!isPaused&&active)frame=requestAnimationFrame(render);
  }
  frame=requestAnimationFrame(render);
  return {setPaused(value){isPaused=value;pointer.x=pointer.y=0;onScroll();}};
}

function start() {
  initialiseReveals();
  createScene().then(controller=>{sceneController=controller;}).catch(error=>{
    console.info('3D enhancement unavailable; the résumé remains accessible.',error.message);
    $('#scene').classList.add('webgl-unavailable');
  });
}
if(document.readyState==='complete')start();else addEventListener('load',start,{once:true});
